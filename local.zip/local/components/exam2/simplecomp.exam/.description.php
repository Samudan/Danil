<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("SIMPLECOMP_EXAM2_NAME_71"),
	"CACHE_PATH" => "Y",
	"PATH" => array(
		"ID" => "ex2simple",
        "NAME" => GetMessage("EXAM2"),
	),
);
?>