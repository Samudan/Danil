<?
$MESS["SIMPLECOMP_EXAM2_NAME_71"] = "Мой компонент - 71";
$MESS["EXAM2"] = "Второй экзамен";
?>