<?
$MESS["SIMPLECOMP_EXAM2_CAT_IBLOCK_ID_71"] = "ID инфоблока с каталогом товаров";
$MESS["SIMPLECOMP_EXAM2_CLASSIF_IBLOCK_ID_71"] = "ID  инфоблокас классификатором";
$MESS["SIMPLECOMP_EXAM2_TEMPLATE_71"] = "Шаблон ссылки на детальный просмотр товара";
$MESS["SIMPLECOMP_EXAM2_PROPERTY_71"] = "Код свойства товара, в котором хранится привязка товара к классификатору";
$MESS["CP_BNL_CACHE_GROUPS_71"] = "Учитывать права доступа";
?>