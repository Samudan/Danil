<?
$MESS["SIMPLECOMP_EXAM2_CAT_TITLE_71"] = "Каталог:";
$MESS["TIME"] = "Метка времени: ";
?>