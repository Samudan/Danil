<?php
$MESS["EX2_51_AUTH_USER"]="Пользователь авторизован: #ID#(#LOGIN#) #NAME#, данные из формы: #NAME_FORM#";
$MESS["EX2_51_NO_AUTH_USER"]="Пользователь не авторизован, данные из формы: #NAME_FORM#";
$MESS["EX2_51_REPLACE"]="Замена данных в отсылаемом письме";